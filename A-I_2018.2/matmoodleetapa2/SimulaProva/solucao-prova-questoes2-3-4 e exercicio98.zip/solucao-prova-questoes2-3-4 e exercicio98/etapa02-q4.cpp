#include<iostream>
#include<cstdlib>
#include<ctime>

using namespace std;

void mostraVetor(int V[12]);
int somaVetor(int V[12]);

main( )
{
    srand(time(NULL));
    int  VA[12], VB[12], i, somaA, somaB;
    for(i = 0; i<12; i++)
    {
        VA[i] = rand()%13+1;
        VB[i] = rand()%13+1;
    }


    cout << "VA: ";
    mostraVetor(VA);

    cout << "VB: ";
    mostraVetor(VB);

    somaA = somaVetor(VA);
    somaB = somaVetor(VB);

    cout << "Soma de VA: " << somaA << endl;
    cout << "Soma de VB: " << somaB << endl;

}

void mostraVetor(int V[12])
{
    int i;
    for(i = 0; i <12; i++)
    {
        cout << V[i] << ", ";
    }
    cout << endl;
}

int somaVetor(int V[12])
{
    int i, soma=0;

    for(i = 0; i <12; i++)
    {
        switch(V[i])
        {
        case 1:
            soma = soma + 15;
            break;
        case 2:
            soma = soma + 20;
            break;
        case 3 ... 7:
            soma = soma + 5;
            break;
        case 8 ... 13:
            soma = soma + 10;
            break;
        default:
            break;
        }
    }

    return soma;
}
