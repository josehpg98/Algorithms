#include<iostream>
using namespace std;
void imprimirSaida(int n[6], char c[6]);
main( )
{
    int n[6], i;
    char c[6];


    for(i=0; i<6;i++){
        cout << "\nDigite o numero " << i << ": ";
        cin >> n[i];
    }

    for(i=0; i<6;i++){
        cout << "\nDigite o caractere " << i << ": ";
        cin >> c[i];
    }


    imprimirSaida(n, c);


}

void imprimirSaida(int n[6], char c[6]){
    int i, k;
    cout << "Saida: " << endl;

    for(i=0; i<6;i++){
        for(k=0; k< n[i]; k++){
            cout << c[i];
        }
        cout << endl;
    }
}
