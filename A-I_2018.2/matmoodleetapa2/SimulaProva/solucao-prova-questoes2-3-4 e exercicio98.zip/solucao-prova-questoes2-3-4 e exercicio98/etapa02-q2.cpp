#include<iostream>
#include<cstdlib>
#include<ctime>

using namespace std;

int verificarPrimos(int M[5][6]);

main( )
{
    srand(time(NULL));
    int  M[5][6], l, c, nPrimos, maiorValor, maiorPosL, maiorPosC;
    for(l = 0; l <5; l++)
    {
        for(c = 0; c <6; c++)
        {
            M[l][c] = rand()%301+1;
            cout << M[l][c] << "\t";
        }
        cout<<"\n";
    }
    cout<<"\n\n";



    maiorValor =M[0][0];
    maiorPosL = 0;
    maiorPosC = 0;
    for(l = 0; l <5; l++)
    {
        for(c = 0; c <6; c++)
        {
            if(M[l][c] > maiorValor){
                maiorValor = M[l][c];
                maiorPosL = l;
                maiorPosC = c;
            }

        }

    }

    nPrimos =  verificarPrimos(M);
    cout << "Numero de primos: " << nPrimos << endl;
    cout << "Maior valor: M[" <<maiorPosL << "][" << maiorPosC <<"] "  << maiorValor << endl;

}

int verificarPrimos(int M[5][6]){
    int l, c, numero, i, primos, divisoes=0;

    primos = 0;
    for(l = 0; l <5; l++)
    {
        for(c = 0; c <6; c++)
        {
            numero = M[l][c];

            divisoes = 0;
            for(i=1; i<=numero; i++){
                if(numero%i==0){
                    divisoes = divisoes +1;
                }
            }

            if(divisoes == 2){
                primos = primos + 1;
                cout << numero << endl;
            }

        }

    }

    return primos;

}
