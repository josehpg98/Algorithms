#include <iostream>
#include<clocale>
#include <ctime>
#include <cstdlib>

using namespace std;

main()
{
    setlocale(LC_ALL, "portuguese");

    srand(time(NULL));

    int  X[10], Y[10], Z[20], i,j, k, aux, total;

    //V1 = {9,8,7,6,5,4,3,2,1,0};


    //le os dois vetores
    for(i=0; i < 10;  i++)
    {
        X[i] = rand() % 100;
        Y[i] = rand() % 100;
    }

    cout << "\n\n";
    for(i=0; i < 10;  i++)
    {
        cout << "X[" << i << "]=" << X[i] << ", ";
    }
    cout << "\n";

    cout << "\n\n";
    for(i=0; i < 10;  i++)
    {
        cout << "Y[" << i << "]=" << Y[i] << ", ";
    }
    cout << "\n";

    //ordena o primeiro vetor
    for(i=0; i < 10;  i++)
    {
        for(j=0; j < 10;  j++)
        {
            if(X[i] < X[j])
            {
                aux = X[i];
                X[i] = X[j];
                X[j] = aux;
            }
        }
    }

    //ordena o primeiro vetor
    for(i=0; i < 10;  i++)
    {
        for(j=0; j < 10;  j++)
        {
            if(Y[i] < Y[j])
            {
                aux = Y[i];
                Y[i] = Y[j];
                Y[j] = aux;
            }
        }
    }


    cout << "\n\n";
    for(i=0; i < 10;  i++)
    {
        cout << "X[" << i << "]=" << X[i] << ", ";
    }
    cout << "\n";

    cout << "\n\n";
    for(i=0; i < 10;  i++)
    {
        cout << "Y[" << i << "]=" << Y[i] << ", ";
    }
    cout << "\n";

    for(i=0; i < 10;  i++) //copia o primeiro vetor para Z
    {
        Z[i]= X[i];
    }

    total = 10; //total de elemento no vetor Z
    for(i=0; i < 10;  i++)
    {

        for(j=0; j <=total;  j++){//la�o para inserir ordenado no vetor Z
            if(j==total || Y[i]< Z[j]){

                for(k=total; k > j;  k--){ //laco para deslocar os elementos do vetor
                   Z[k] =  Z[k-1];
                }

                Z[j] = Y[i]; //insere o elemento do vetor Y em Z

                total++; //incrementa o valor total de elementos do vetor Z
                break;
            }
        }
    }


    cout << "\n\n";
    for(i=0; i < 20;  i++)
    {
        cout << "Z[" << i << "]=" << Z[i] << ", ";
    }
    cout << "\n";

}
