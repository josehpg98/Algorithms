#include<iostream>
#include<locale.h>
#include <stdlib.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    char m [5][5];
    cout<<"matriz"<<endl;
    for(int i = 0; i<5; i++)
    {
        cout<<endl;
            for(int j = 0; j<4-i; j++)
            {
                m[i][j]='A';
            }
            for(int c = 4; c>4-i; c--)
            {
                m[i][c]='B';
            }
            for(int k = 0; k<5; k++)
            {
                m[4-k][k]='0';
                cout<<m[i][k]<<" ";
            }
    }

}
