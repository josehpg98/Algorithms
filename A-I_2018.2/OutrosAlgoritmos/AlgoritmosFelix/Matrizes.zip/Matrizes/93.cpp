#include<iostream>
#include<locale.h>
#include <stdlib.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int m [5][5];
    int st=0,s2=0,s4=0,sdp=0,sds=0;
    cout<<"matriz"<<endl;
    for(int i = 0; i<5; i++)
    {
        cout<<endl;
        for(int j = 0; j<5; j++)
        {
            m[i][j]=rand() % 100;
            cout<<m[i][j]<<" ";
            st+=m[i][j];
        }
    }
        for(int i = 0; i<5; i++)
    {
          sdp += m[i][i];
          sds += m[4-i][i];
          s4 += m[3][i];
          s2 += m[i][1];
    }

    cout<<endl;
    cout<<"----------------------------"<<endl;
    cout<<"soma de todos os numeros :"<<st<<endl;
    cout<<"soma da diagonal principal :"<<sdp<<endl;
    cout<<"soma de diagonal secundaria :"<<sds<<endl;
    cout<<"soma da linha 4 :"<<s4<<endl;
    cout<<"soma de coluna 2:"<<s2<<endl;
}


