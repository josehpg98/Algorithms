#include<iostream>
#include<locale.h>
#include <stdlib.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int m [3][4];
    cout<<"matriz original"<<endl;
    for(int i = 0; i<3; i++)
    {
        cout<<endl;
        for(int j = 0; j<4; j++)
        {
            m[i][j]=rand() % 100;
            cout<<m[i][j]<<" ";
        }
    }
    cout<<endl;
    cout<<"----------------"<<endl;
    cout<<"matriz alterada"<<endl;
    int aux;
    for(int j = 0; j<4; j++){
        aux = m[0][j];
        m[0][j]= m[2][j];
        m[2][j]= aux;
    }
      for(int i = 0; i<3; i++)
    {
        cout<<endl;
        for(int j = 0; j<4; j++)
        {
            cout<<m[i][j]<<" ";
        }
    }

}
