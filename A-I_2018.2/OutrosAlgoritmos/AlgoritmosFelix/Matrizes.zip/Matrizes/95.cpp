#include<iostream>
#include<locale.h>
#include <stdlib.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int m [3][3]={
    1,2,3,
    4,5,6,
    7,8,9};
    int x[3][3];
    cout<<"matriz original"<<endl;
    for(int i = 0; i<3; i++)
    {
        cout<<endl;
        for(int j = 0; j<3; j++)
        {
            cout<<m[i][j]<<" ";
            x[i][j]= m[j][2-i];
        }
    }
    cout<<endl;
    cout<<"----------------"<<endl;
    cout<<"matriz alterada"<<endl;
    for(int i = 0; i<3; i++)
    {
        cout<<endl;
        for(int j = 0; j<3; j++)
        {
            cout<<x[i][j]<<" ";

        }
    }
}
