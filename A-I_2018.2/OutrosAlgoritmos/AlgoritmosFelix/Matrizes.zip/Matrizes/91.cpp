#include<iostream>
#include<locale.h>
#include <stdlib.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int m [3][6];
    cout<<"matriz original"<<endl;
    for(int i = 0; i<3; i++)
    {
        cout<<endl;
        for(int j = 0; j<6; j++)
        {
            m[i][j]=rand() % 100;
            cout<<m[i][j]<<" ";
        }
    }
    cout<<endl;
    cout<<"---------------------------------"<<endl;
    cout<<"digite um numero"<<endl;
    int n;
    cin>>n;
    cout<<"---------------------------------"<<endl;
    cout<<"matriz com multiplica��o"<<endl;
    for(int i = 0; i<3; i++)
    {
        cout<<endl;
        for(int j = 0; j<6; j++)
        {
            m[i][j]*=n;
            cout<<m[i][j]<<" ";
        }
    }

}
