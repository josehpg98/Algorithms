#include<iostream>
#include<locale.h>
#include <stdlib.h>
#include <ctime>
#include <clocale>
using namespace std;
main(){
   srand(time(NULL));
   setlocale(LC_ALL,"Portuguese");
   int A[10],v,t=0;
   for(int i = 0;i<10;i++){
       A[i]=rand() % 100;
       cout<<A[i]<<endl;
   }
   cout<<"Qual numero voc� quer multiplicar no vetor?";
   cin>>v;
   for(int i = 0;i<10;i++){
      A[i]*=v;
      cout<<A[i]<<endl;
    }


}
