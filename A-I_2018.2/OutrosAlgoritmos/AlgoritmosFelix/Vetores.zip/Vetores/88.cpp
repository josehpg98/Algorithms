#include<iostream>
#include<locale.h>
#include <stdlib.h>
#include <ctime>
#include <clocale>
using namespace std;
main(){
   srand(time(NULL));
   setlocale(LC_ALL,"Portuguese");
   int A[50],ma=0,me=100;
   for(int i = 0;i<50;i++){
      A[i]=rand() % 100;
      if(A[i]<me){
        me=A[i];
      }
      else if(A[i]>ma){
        ma=A[i];
      }
      cout<<A[i]<<endl;
   }
   cout<<"o maior numero foi "<<ma<<" e o menor numero foi "<<me;
}
