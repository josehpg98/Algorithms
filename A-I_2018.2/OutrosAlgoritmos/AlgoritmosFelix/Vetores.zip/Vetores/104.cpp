#include<iostream>
#include<locale.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int a[20],v[20];
    cout<<"-----------A----------"<<endl;
    for(int i = 0;i<20;i++){
        cin>>a[i];
    }
    v[19] = a[0];
    cout<<"-----------V----------"<<endl;
    for(int i = 0;i<19;i++){
        v[i]=a[i+1];
        cout<<v[i]<<endl;
    }
    cout<<v[19];
}

