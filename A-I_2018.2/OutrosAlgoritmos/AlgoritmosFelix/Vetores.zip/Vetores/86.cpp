#include<iostream>
#include<locale.h>
#include <stdlib.h>
#include <ctime>
#include <clocale>
using namespace std;
main(){
   setlocale(LC_ALL,"Portuguese");
   int V[10],im=0;
   for(int i = 0;i<10;i++){
     cout<<"Digite o "<<i+1<<"� numero:";
     cin>>V[i];
     if(V[i]<0){
        im++;
     }
   }
   cout<<"O total de numeros negativos "<<im;
}

//NUMEROS RANDOMICOS!
/*main(){
   srand(time(NULL));
   setlocale(LC_ALL,"Portuguese");
   int V[10],im=0,s;
   for(int i = 0;i<10;i++){
     s=rand() % 2;
     V[i]=rand() % 100;
     if(s==0){
        V[i]*=-1;
     }
     if(V[i]<0){
        im++;
     }
     cout<<V[i]<<endl;
   }
   cout<<"O total de numeros negativos "<<im;
}
*/
