#include<iostream>
#include<locale.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int v[25],aux;
    bool ve=true;
    for(int i = 0; i<25; i++)
    {
        cin>>v[i];
    }
    for(int i = 0; i<24; i++)
    {
        for(int j = i+1; j<25; j++)
        {
            if(v[i]>v[j])
            {
                aux = v[i];
                v[i]=v[j];
                v[j]=aux;
            }
        }
    }
    cout<<"--------valores ordenado-----------"<<endl;
    for(int i = 0; i<25; i++)
    {
        cout<<v[i]<<endl;
    }
}
