#include<iostream>
#include<locale.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int v[20],n,t=0,ti=0;
    for(int i = 0; i<20; i++)
    {
        cout<<"digite o "<<i+1<<"� numero"<<endl;
        {
            cin>>v[i];
        }
        if(v[i]%2==0)
        {
            t++;
        }
        else{
            ti++;
        }
    }
    int p[t],im[ti];
    t=0;
    ti=0;
    for(int i = 0; i<20; i++)
    {
        if(v[i]%2==0)
        {
            p[t]=v[i];
            t++;
        }
        else{
            im[ti]=v[i];
            ti++;
        }
    }
    cout<<"----------pares----------"<<endl;
    for(int i = 0;i<t;i++){
        cout<<p[i]<<endl;
    }
     cout<<"---------impares----------"<<endl;
    for(int i = 0;i<ti;i++){
        cout<<im[i]<<endl;
    }
}
