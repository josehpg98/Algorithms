#include<iostream>
#include<locale.h>
#include <stdlib.h>
#include <ctime>
#include <clocale>
using namespace std;
main(){
   srand(time(NULL));
   setlocale(LC_ALL,"Portuguese");
   int A[80],ma=0,p;
   for(int i = 0;i<80;i++){
      A[i]=rand() % 100;
       if(A[i]>ma){
        ma=A[i];
        p=i;
      }
      cout<<A[i]<<endl;
   }
   cout<<"o maior numero foi "<<ma<<" na posi��o "<<p;
}
