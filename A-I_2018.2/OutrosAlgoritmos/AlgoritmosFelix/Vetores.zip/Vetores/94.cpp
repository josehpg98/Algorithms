#include<iostream>
#include<locale.h>
#include <stdlib.h>
#include <ctime>
#include <clocale>
using namespace std;
main(){
   setlocale(LC_ALL,"Portuguese");
   int A[10],B[10],Y[20];
   cout<<"----------A----------"<<endl;
   for(int i = 0;i<10;i++){
      cin>>A[i];
   }
   cout<<"---------B-----------"<<endl;
   for(int i = 0;i<10;i++){
      cin>>B[i];
   }
   cout<<"------------Y---------------"<<endl;
   for(int i = 0;i<10;i++){
        Y[i]=A[i];
        Y[i+10]=B[i];
    }
    for(int i = 0;i<20;i++){
        cout<<Y[i]<<endl;
    }
}
