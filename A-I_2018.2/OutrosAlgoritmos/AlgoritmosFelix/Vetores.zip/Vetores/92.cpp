#include<iostream>
#include<locale.h>
#include <stdlib.h>
#include <ctime>
#include <clocale>
using namespace std;
main(){
   srand(time(NULL));
   setlocale(LC_ALL,"Portuguese");
   int A[30],p=0,im=0;
   for(int i = 0;i<30;i++){
      A[i]=rand() % 100;
      if(A[i]%2==1){
        im++;
      }
      else{
        p++;
      }
      cout<<A[i]<<endl;
   }
   cout<<"o o total de numeros pares foi "<<p<<" e o total de impares foi "<<im;
}
