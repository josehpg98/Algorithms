#include<iostream>
#include<locale.h>
#include <stdlib.h>
#include <ctime>
#include <clocale>
using namespace std;
main(){
   srand(time(NULL));
   setlocale(LC_ALL,"Portuguese");
   int A[10],v,t=0;
   for(int i = 0;i<10;i++){
       A[i]=rand() % 100;
   }
   cout<<"Qual numero voc� quer verificar no vetor?";
   cin>>v;
   for(int i = 0;i<10;i++){
      if(A[i]==v){
        t++;
      }
   }
   cout<<"O total de vezes que o numero "<<v<<" aparece no vetor � "<<t;
}

//VALORES DIGITADOS!
/*main(){

   setlocale(LC_ALL,"Portuguese");
   int A[10],v,t=0;
   for(int i = 0;i<10;i++){
     cout<<"Digite o "<<i+1<<"� numero:";
     cin>>A[i];
   }
   cout<<"Qual numero voc� quer verificar no vetor?";
   cin>>v;
   for(int i = 0;i<10;i++){
      if(A[i]==v){
        t++;
      }
   }
   cout<<"O total de vezes que o numero "<<v<<" aparece no vetor � "<<t;
}*/
