#include<iostream>
#include<locale.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int v[25],n,t=0,aux;
    bool ve=true;
    for(int i = 0; i<25; i++)
    {
        cout<<"digite o "<<i+1<<"� numero(n�o pode ser repetido)"<<endl;
        while(ve == true)
        {
            ve=false;
            cin>>n;
            for(int j =0; j<i; j++)
            {
                if (n == v[j])
                {
                    ve = true;
                }
            }
            if(ve==false)
            {
                v[i]=n;
            }
            else
            {
                cout<<"numero repetido"<<endl;
            }
        }
        ve=true;
        if(v[i]%2==0)
        {
            t++;
        }
    }
    int p[t];
    t=0;
    for(int i = 0; i<25; i++)
    {
        if(v[i]%2==0)
        {
            p[t]=v[i];
            t++;
        }
    }
    cout<<"-------------p----------"<<endl;
    for(int i = 0; i<t-1; i++)
    {
        for(int j = i+1; j<t; j++){
          if(p[j]>p[i]){
            aux = p[i];
            p[i]=p[j];
            p[j]=aux;
          }
    }
    }
    for(int i = 0; i<t; i++){
        cout<<p[i]<<endl;
    }
}
