#include<iostream>
#include<locale.h>
#include <stdlib.h>
#include <ctime>
#include <clocale>
using namespace std;
main(){
   srand(time(NULL));
   setlocale(LC_ALL,"Portuguese");
   int A[20],t;
   for(int i = 0;i<20;i++){
      A[i]=rand() % 100;
      cout<<A[i]<<endl;
   }
   cout<<"------------------------------"<<endl;
   cout<<"valores trocados"<<endl<<endl;
   for(int i = 0;i<10;i++){
      t=A[i];
      A[i]=A[i+10];
      A[i+10]=t;
   }
   for(int i = 0;i<20;i++){
      cout<<A[i]<<endl;
   }

}
