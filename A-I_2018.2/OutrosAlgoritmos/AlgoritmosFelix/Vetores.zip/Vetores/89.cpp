#include<iostream>
#include<locale.h>
#include<string>
using namespace std;
main()
{

    setlocale(LC_ALL,"Portuguese");
    float t[12],t2[12],tn=0,tme=100,tma=-100,m=0;
    string me[12];
    me[0]="Janeiro";
    me[1]="Fevereiro";
    me[2]="Mar�o";
    me[3]="Abril";
    me[4]="Maio";
    me[5]="Junho";
    me[6]="Julho";
    me[7]="Agosto";
    me[8]="Setembro";
    me[9]="Outubro";
    me[10]="Novembro";
    me[11]="Dezembro";

    for(int i = 0 ; i<12; i++)
    {
        cout<<"Informe a temperatura no m�s de "<<me[i]<<endl;
        cin>>t[i];
        if(t[i]<0)
        {
            tn++;
        }
        m+=t[i];
        t2[i]=t[i]+((t[i]*3)/100);
    }
    tme = t[0];
    tma = t[0];
    for(int i = 0 ; i<12; i++)
    {
        if(t[i] < tme) //???
        {
            tme=t[i];
        }
        else if(t[i]>tma)
        {
            tma=t[i];
        }
    }
        cout<<"O total de temperaturas no ano foi de "<<tn<<endl;
        cout<<"A maior temperatura foi de "<<tma<<" graus e a menor foi de "<<tme<<" graus"<<endl;
        cout<<"A media anual de temperatura foi de "<<m/12<<endl;
        for(int i = 0 ; i<12; i++)
        {
            cout<<"a temperatura com 3% de acrescimo no mes de "<<me[i]<<" foi de "<<t2[i]<<" graus"<<endl;
        }
    }
