#include<iostream>
#include<locale.h>
using namespace std;
main()
{
    setlocale(LC_ALL,"Portuguese");
    int A[10],B[10],t=0,l;
    cout<<"----------A----------"<<endl;
    for(int i = 0; i<10; i++)
    {
        cin>>A[i];
    }
    cout<<"---------B-----------"<<endl;
    for(int i = 0; i<10; i++)
    {
        cin>>B[i];
        for(int j = 0; j<10; j++)
        {
            if(B[i]==A[j] && l!= A[j])
            {
               t++;
               l=B[i];
            }
        }
    }
    int Y[t];
    t=0;
    cout<<"------------Y---------------"<<endl;
    for(int i = 0; i<10; i++)
    {
      if(B[i]==A[i]){
        Y[t]=B[i];
        t++;
      }
    }
    for(int i = 0; i<t; i++)
    {
        cout<<Y[i]<<endl;
    }
}
