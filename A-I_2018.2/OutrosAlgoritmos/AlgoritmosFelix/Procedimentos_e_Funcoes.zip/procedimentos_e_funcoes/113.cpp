#include<iostream>
#include<locale.h>
using namespace std;
bool perfeito(int n)
{
    bool per=false;
    int p=0;
    for(int i = 1; i<n; i++)
    {
        if(n%i==0)
        {
            p+=i;
        }
    }
    if(p==n)
    {
        per=true;
    }
    return per;
}
main()
{
    setlocale(LC_ALL,"Portuguese");
    int n;
    do
    {
        cout<<"digite um numero(positivo):"<<endl;
        cin>>n;
    }
    while(n<0);

    if(perfeito(n)== true)
    {
        cout<<"o numero "<<n<<" � perfeito";
    }
    else
    {
        cout<<"o numero "<<n<<" n�o � perfeito";
    }
}
