#include<iostream>
#include<locale.h>
#include<cstdlib>
using namespace std;
float pesoIdeal(float a,char s){
    float p;
    if(s == 'M'){
        p = 72.7*a-58;
    }
    else{
        p=62.1*a-44.7;
    }
    return p;
    }
main()
{
    setlocale(LC_ALL,"Portuguese");
    char s = 'a';
    float a;
    while(s!='M' && s!='F'){
        cout<<"informe seu sexo(M ou F)"<<endl;
        cin>>s;
        s=toupper(s);
    }
    cout<<"informe sua altura:"<<endl;
    cin>>a;

    cout<<"o peso ideal para voc� � : "<<pesoIdeal(a,s)<<"KG";
}
