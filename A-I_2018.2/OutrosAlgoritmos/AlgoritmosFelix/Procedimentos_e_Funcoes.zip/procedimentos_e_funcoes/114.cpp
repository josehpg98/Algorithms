#include<iostream>
#include<locale.h>
#include <stdlib.h>
using namespace std;

int maior(int m[5][5])
{
    int ma= 0;
    for(int i = 0; i<5; i++)
    {
        for(int j = 0; j<5; j++)
        {
            if(m[i][j]>ma)
            {
                ma=m[i][j];
            }
        }
    }
    return ma;
}
bool contem(int m[5][5])
{
    int t;
    bool tem = false;
    cout<<"qual valor voc� quer vereficar?"<<endl;
    cin>>t;
    for(int i = 0; i<5; i++)
    {
        for(int j = 0; j<5; j++)
        {
            if(t==m[i][j])
            {
                tem=true;
            }
        }
    }
    return tem;
}
void diagP(int m[5][5])
{
    int dP[5];
    for(int j = 0; j<5; j++)
    {
        dP[j]=m[j][j];
    }
    cout<<"os numeros da diagonal principal s�o :";
    for(int j = 0; j<5; j++)
    {
        cout<<dP[j]<<" ";
    }
}



main()
{
    setlocale(LC_ALL,"Portuguese");
    int m [5][5];
    cout<<"matriz"<<endl;
    for(int i = 0; i<5; i++)
    {
        cout<<endl;
        for(int j = 0; j<5; j++)
        {
            m[i][j]=rand() % 11;
            cout<<m[i][j]<<" ";
        }
    }
    cout<<endl;
    cout<<"o maior numero � "<<maior(m)<<endl;
    bool tem=contem(m);
    if(tem==true)
    {
        cout<<"o numero contem na matriz"<<endl;
    }
    else
    {
        cout<<"o numero n�o est� na matriz"<<endl;
    }
    diagP(m);


}
