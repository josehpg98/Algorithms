#include<iostream>
#include<locale.h>
#include<cstdlib>
using namespace std;
float media(float n[3],char tm){
    float m=0;
       if(tm=='A'){
        for(int i = 0;i<3;i++){
            m+=n[i];
        }
        m=m/3;
       }
       else if(tm=='P'){
        n[0]=0.5;
        n[1]=0.3;
        n[2]=0.2;
        m=n[0]+n[1]+n[2];
       }
       else{
        if(tm=='A'){
        for(int i = 0;i<3;i++){
            m+=1/n[i];
        }
        m=3/m;
       }
    }
    return m;
}
main()
{
    setlocale(LC_ALL,"Portuguese");
    char tm = 'a';
    float n[3];
    for(int i=0;i<3;i++){
        do{
            cout<<"informe a "<<i+1<<"� nota:(0 a 10)"<<endl;
            cin>>n[i];
        }while(n[i]<0||n[i]>10);
    }
    while(tm!='A' && tm!='P' && tm!='H'){
        cout<<"informe o tipo de media que voc� gostaria(A=aritm�tica,P=ponderada,H=harm�nica)"<<endl;
        cin>>tm;
        tm=toupper(tm);
    }
    cout<<"a m�dia escolhida das notas � :"<<media(n,tm);


}
