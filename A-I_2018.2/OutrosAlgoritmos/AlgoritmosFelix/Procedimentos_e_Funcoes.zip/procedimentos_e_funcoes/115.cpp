#include<iostream>
#include<locale.h>
#include <stdlib.h>
using namespace std;

void consultar(float s)
{
    cout<<"seu saldo � "<<s<<"R$"<<endl;
}
float saque(float s)
{
    float sa;
    cout<<"quanto deseja sacar?"<<endl;
    cin>>sa;
    if(s<sa){
        cout<<"saque invalido!";
    }
    else{
        s=s-sa;
    }
    return s;
}
float deposito(float s)
{
    float d;
    cout<<"quanto deseja depositar?"<<endl;
    cin>>d;
    if(d<=0){
        cout<<"deposito invalido!";
    }
    else{
        s=s+d;
    }
    return s;
}



main()
{
    setlocale(LC_ALL,"Portuguese");
    char t;
    float s = 0;
    do{
        cout<<"-----------------------------------"<<endl;
        cout<<"a)consultar     c)depositar"<<endl;
        cout<<"b)sacar         d)sair"<<endl;
        cout<<"-----------------------------------"<<endl;
        cout<<"qual opera��o deseja fazer?"<<endl;
        cin>>t;
        t=tolower(t);
        if(t=='a'){
            consultar(s);
        }
        else if(t=='b'){
            s=saque(s);
        }
        else if(t=='c'){
            s=deposito(s);
        }
        else if(t=='d'){
            cout<<"tenha um bom dia!";
        }
        else {
            cout<<"opera��o invalida!"<<endl;
        }
    }while(t!='d');

}
