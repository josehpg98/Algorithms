#include<iostream>
#include<locale.h>
using namespace std;
int fatorial(int n){
    int f=1;
    for(int i= n;i>0;i--){
        f*=i;
    }
    return f;
    };
main()
{
    setlocale(LC_ALL,"Portuguese");
    int n[10],nf[10];
    for(int i=0;i<10;i++){
      cout<<"qual o "<<i+1<<"� numero voc� quer calcular o fatorial?"<<endl;
    cin>>n[i];
    nf[i]=fatorial(n[i]);
    }
    cout<<"---------vetor de fatoriais--------"<<endl;
    for(int i = 0;i<10;i++){
        cout<<nf[i]<<endl;
    }
}
