#include<iostream>
#include<locale.h>
using namespace std;
float reajuste(float s){
    s=((s*15)/100)+s;
    return s;
    };
main()
{
    setlocale(LC_ALL,"Portuguese");
    float s;
    cout<<"qual � o seu salario?"<<endl;
    cin>>s;
    cout<<"seu salario reajustado em 15% � "<<reajuste(s)<<" R$";
}
