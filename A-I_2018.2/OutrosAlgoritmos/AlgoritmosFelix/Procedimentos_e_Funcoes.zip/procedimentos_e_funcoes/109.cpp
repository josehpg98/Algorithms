#include<iostream>
#include<locale.h>
using namespace std;
int fatorial(int n){
    int f=1;
    for(int i= n;i>0;i--){
        f*=i;
    }
    return f;
    };
main()
{
    setlocale(LC_ALL,"Portuguese");
    int n;
    cout<<"qual numero voc� quer calcular o fatorial?"<<endl;
    cin>>n;
    cout<<"o fatorial de "<<n<<" � : "<<fatorial(n);
}
