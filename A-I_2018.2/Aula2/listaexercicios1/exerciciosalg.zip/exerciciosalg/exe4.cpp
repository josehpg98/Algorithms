#include<iostream>
using namespace std;
main()
{
  int h,

  cout<<"\n informe o tempo de dura��o em segundos : ";
  cin>> s;


  h =  s  / 3600
  cin>> h;



}
