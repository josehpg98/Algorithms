#include<iostream>
using namespace std;
main()
{
int val, reaj, valorj;

    cout<<"\n insira o valor do produto: ";
    cin>> val;

    reaj = (val * o,10);
    valorj = (val - reaj);

    cout<<"\n o valor com o desconto é :" >> valorj;
}
