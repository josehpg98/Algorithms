#include <iostream>
using namespace std;
main()
    int mes, reaj;
{
   cout<<"\n informe o sal�rio mensal atual: ";
   cin>> mes;

   cout<<"\n informe o percentual de reajuste mensal: ";
   cin>> reaj;
   return 0;
}
