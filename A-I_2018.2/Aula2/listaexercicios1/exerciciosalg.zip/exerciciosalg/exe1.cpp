#include<iostream>
using namespace std;
main()
{
  int n1, n2, s;

  cout<<"\n informe o primeiro n�mero : ";
  cin>> n1;

  cout<<"n informe o segundo n�mero : ";
  cin>> n2;

  s = n1 + n2;

  cout<<"\n a soma dos n�meros � : " << s;
  cout<<"\n\n";

}
