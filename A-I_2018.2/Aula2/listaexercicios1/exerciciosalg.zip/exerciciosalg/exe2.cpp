#include<iostream>
using namespace std;
int main()
{
  int n1, n2, s;

  cout<<"\n informe o primeiro número : ";
  cin>> n1;

  cout<<"n informe o segundo número : ";
  cin>> n2;

  s = n1 - n2;

  cout<<"\n a subtração dos números é : " << s;
  cout<<"\n\n";
  return 0;
}


