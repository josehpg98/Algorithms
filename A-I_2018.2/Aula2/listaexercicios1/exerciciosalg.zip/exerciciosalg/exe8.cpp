#include <iostream>
using namespace std;
main()
{
    float area, base, altura;

    cout<<"\n informe a medida da base: ";
    cin>> base;

    cout<<"\in informe a medida da altura: ";
    cin>> altura;

    area = (base * altura) / 2;

    cout<<"o tamanho da �rea �: " << area;

}
