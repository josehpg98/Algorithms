#include<iostream>
using namespace std;
main()
{
  int v1, q, c;

  cout<<"informe um valor: ";
  cin>> v1;

  q = v1 * v1;
  c = v1 * v1 * v1;


  cout<<"o quadrado �: " << q;
  cout<<"o cubo �: " << c;
  return 0;

}
